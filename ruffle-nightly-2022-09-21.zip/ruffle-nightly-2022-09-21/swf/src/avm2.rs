pub mod read;
pub mod types;
pub mod write;

mod opcode;
