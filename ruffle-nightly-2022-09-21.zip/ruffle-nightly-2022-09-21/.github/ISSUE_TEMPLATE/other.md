---
name: Other
about: File an issue that does not fit elsewhere
title: ''
labels:
assignees: ''

---

<!--
If you have a question about Ruffle, you can ask for help on our Discord chat:
https://discord.gg/ruffle

Also consult the FAQ for common issues and questions:
https://github.com/ruffle-rs/ruffle/wiki/Frequently-Asked-Questions-For-Users
-->
