//! `flash.events` namespace

pub mod event;
pub mod eventdispatcher;
pub mod gesture_event;
pub mod ieventdispatcher;
pub mod mouse_event;
