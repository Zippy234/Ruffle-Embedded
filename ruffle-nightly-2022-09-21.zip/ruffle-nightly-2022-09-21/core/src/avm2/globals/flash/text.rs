//! `flash.text` namespace

pub mod font;
pub mod textfield;
pub mod textformat;
