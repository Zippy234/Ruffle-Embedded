//! `flash.external` namespace

pub mod externalinterface;
