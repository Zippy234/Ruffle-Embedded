//! AVM2 String representation

pub use crate::string::AvmString;
