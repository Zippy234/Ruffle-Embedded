mod format;
mod injector;

pub use format::{AutomatedEvent, MouseButton};
pub use injector::{InputInjector, MouseButtons};
